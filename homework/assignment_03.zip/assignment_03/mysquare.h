#include <stdlib.h>
#include <stdio.h>

void generateNums(int *myarr, int len);
void squareNums(int *myarr, int len);
void printNums(int *myarr, int len);
